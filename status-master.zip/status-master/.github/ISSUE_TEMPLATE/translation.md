---
name: Translation
about: Have you translated this mod into another language?
title: ''
labels: translation
assignees: henkelmax

---

**Locale code**
Please provide the [Locale code](https://minecraft.gamepedia.com/Language#Available_languages) that Minecraft uses for this language.

**Translation**
Please use a [https://gist.github.com/](https://gist.github.com/) link instead of pasting the translation here.
